import InfoBox from "./InfoBox";
import InfoBoxFullWidth from "./InfoBoxFullWidth";

export { InfoBox, InfoBoxFullWidth };
