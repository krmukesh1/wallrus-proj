import GamePlayerPage from "./GamePlayerPage";
import WelcomePage from "./WelcomePage";
export { GamePlayerPage, WelcomePage };
