const styles = () => ({
	link: {
		textDecoration: "none",
		color: "inherit",
	},
	text: {
		display: "inline-block",
		verticalAlign: "text-bottom",
	},
});
export default styles;
