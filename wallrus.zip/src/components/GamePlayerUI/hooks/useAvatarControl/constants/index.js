import * as avatarControlActions from "./actions";

export { avatarControlActions };
