const styles = () => ({
	loadingMessage: {
		position: "absolute",
		top: "40%",
		left: "40%",
	},
});
export default styles;
