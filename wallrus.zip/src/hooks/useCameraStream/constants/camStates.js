export const STANDBY = "STANDBY";
export const RUNNING = "RUNNING";
export const PAUSED = "PAUSED";
export const STOPPED = "STOPPED";
export const ERROR = "ERROR";
