export const AVC_TOUCHSCREEN = "AVC_TOUCHSCREEN";
export const AVC_IPT = "AVC_IPT";
