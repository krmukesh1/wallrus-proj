export const CONTINUOUS = "MIS_M_CONTINUOUS";
export const DISCRETE = "MIS_M_DISCRETE";
