export const FILL_WINDOW = "RM_FILL_WINDOW";
export const ACTUAL_SIZE = "RM_ACTUAL_SIZE";
export const ARBITRARY = "RM_ARBITRARY";
