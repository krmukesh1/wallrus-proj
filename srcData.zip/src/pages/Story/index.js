import React from "react";
import StoryStepView from "./view";

const Story = () => {
	return <StoryStepView />;
};
export default Story;
