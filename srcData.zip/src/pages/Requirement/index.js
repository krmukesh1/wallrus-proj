import React from "react";
import RequirementsView from "./view";

const Requirement = () => {
	return <RequirementsView />;
};

export default Requirement;
