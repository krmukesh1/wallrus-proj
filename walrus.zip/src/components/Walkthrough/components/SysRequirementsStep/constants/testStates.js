export const PROMPT = "TEST_ST_PROMPT";
export const RUNNING = "TEST_ST_RUNNING";
export const DONE = "TEST_ST_DONE";
export const ERROR = "TEST_ST_ERROR";
