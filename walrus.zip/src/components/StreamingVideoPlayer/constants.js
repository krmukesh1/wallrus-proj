export const SVP_STANDBY = "SVP_STANDBY";
export const SVP_LOADING = "SVP_LOADING";
export const SVP_RUNNING = "SVP_RUNNING";
export const SVP_STOPPED = "SVP_STOPPED";
export const SVP_ERROR = "SVP_ERROR";
