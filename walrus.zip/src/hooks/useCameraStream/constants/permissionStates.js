export const NOT_REQUESTED = "NOT_REQUESTED";
export const REQUESTED = "REQUESTED";
export const GRANTED = "GRANTED";
export const DENIED = "DENIED";
export const ERROR = "ERROR";
